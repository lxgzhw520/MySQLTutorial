create definer = lxgzhw@`%` view myv1 as
select `e`.`last_name` AS `last_name`, `d`.`department_name` AS `department_name`, `j`.`job_title` AS `job_title`
from ((`mysql_tutorial`.`employees` `e` join `mysql_tutorial`.`departments` `d` on ((`e`.`department_id` = `d`.`department_id`)))
         join `mysql_tutorial`.`jobs` `j` on ((`j`.`job_id` = `e`.`job_id`)));

