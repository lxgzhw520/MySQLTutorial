create definer = lxgzhw@`%` view myv2 as
select avg(`mysql_tutorial`.`employees`.`salary`)   AS `ag`,
       `mysql_tutorial`.`employees`.`department_id` AS `department_id`
from `mysql_tutorial`.`employees`
group by `mysql_tutorial`.`employees`.`department_id`;

